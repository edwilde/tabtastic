import './assets/index.ts-BeCs5FeQ.js';
